#' InsurFair Package
#'
#' ....
#'
#'
#' @docType package
#'
#' @author Arthur Charpentier \email{arthur.charpentier@gmail.com}
#'
#' @name package1
NULL
